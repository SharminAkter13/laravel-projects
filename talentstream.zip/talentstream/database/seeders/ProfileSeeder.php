<?php


namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Profile;

class ProfileSeeder extends Seeder
{
    public function runs(): void
    {
        Profile::factory()->count(10)->create();
    }
}

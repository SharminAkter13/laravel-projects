<!-- resources/views/home.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>My Laravel Page</title>
</head>
<body>
<h1>About Page</h1>
<p>This is the About page of my Laravel app.</p>
</body>
</html>

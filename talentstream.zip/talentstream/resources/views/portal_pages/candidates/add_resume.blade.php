@extends('main')
@section('content')

    <!-- Page Header Start -->
      <div class="page-header" style="background: url(portal/assets/img/banner1.jpg);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">Create Resume</h2>
                <ol class="breadcrumb">
                  <li><a href="#"><i class="ti-home"></i> Home</a></li>
                  <li class="current">Resumes</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->   

    <!-- Content section Start --> 
    <section id="content">
      <div class="container">
        <div class="row">
          <div class="col-md-9 col-md-offset-2">
            <div class="page-ads box">
              <div class="post-header">
                <p>Already have an account? <a href="/my-account">Click here to login</a></p>
              </div>
              <form class="form-ad">
                <div class="divider"><h3>Basic information</h3></div>
                <div class="form-group">
                  <label class="control-label" for="textarea">Name</label>
                  <input type="text" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                  <label class="control-label" for="textarea"></label>
                  <label class="control-label" for="textarea">Email</label>
                  <input type="text" class="form-control" placeholder="Your@domain.com" >
                </div>
                <div class="form-group">
                  <label class="control-label" for="textarea">Profession Title</label>
                  <input type="text" class="form-control"  placeholder="Headline (e.g. Front-end developer)">
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">Location</label>
                  <input type="text" class="form-control"  placeholder="Location, e.g">
                </div>  
                <div class="form-group">
                  <label class="control-label" for="textarea">Web</label>
                  <input type="text" class="form-control"  placeholder="Website address">
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">Pre Hour</label>
                  <input type="text" class="form-control"  placeholder="Salary, e.g. 85">
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">Age</label>
                  <input type="text" class="form-control"  placeholder="Years old">
                </div>
                <div class="form-group">
                  <div class="button-group">
                    <div class="action-buttons">
                      <div class="upload-button">
                        <button class="btn btn-common">Choose a cover image</button>
                        <input id="cover_img_file" type="file">
                      </div>
                    </div>
                  </div>
                </div>  
                <div class="divider"><h3>Education</h3></div>   
                <div class="form-group">
                  <label class="control-label" for="textarea">Degree</label>
                  <input type="text" class="form-control"  placeholder="Degree, e.g. Bachelor">
                </div>  
                <div class="form-group">
                  <label class="control-label" for="textarea">Field of Study</label>
                  <input type="text" class="form-control"  placeholder="Major, e.g Computer Science">
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">School</label>
                  <input type="text" class="form-control" placeholder="School name, e.g. Massachusetts Institute of Technology">
                </div>
                <div class="form-group">
                  <div class="row">
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">From</label>
                      <input type="text" class="form-control"  placeholder="e.g 2014">
                    </div>
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">To</label>
                      <input type="text" class="form-control"  placeholder="e.g 2018">
                    </div>
                  </div>
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">Description</label>  
                  <textarea class="form-control" rows="7"></textarea>                
                </div>                  
                <div class="form-group">
                  <div class="button-group">
                    <div class="action-buttons">
                      <div class="upload-button">
                        <button class="btn btn-common">Choose a cover Logo</button>
                        <input id="cover_img_file" type="file">
                      </div>
                    </div>
                  </div>
                </div>  
                <div class="add-post-btn">
                  <div class="pull-left">
                    <a href="#" class="btn-added"><i class="ti-plus"></i> Add New Education</a>
                  </div>
                  <div class="pull-right">
                    <a href="#" class="btn-delete"><i class="ti-trash"></i> Delete This</a>
                  </div>
                </div> 
                <div class="divider"><h3>Work Experience</h3></div>   
                <div class="form-group">
                  <label class="control-label" for="textarea">Company Name</label>
                  <input type="text" class="form-control"  placeholder="Company name">
                </div>  
                <div class="form-group">
                  <label class="control-label" for="textarea">Title</label>
                  <input type="text" class="form-control"  placeholder="e.g UI/UX Researcher">
                </div> 
                <div class="form-group">
                  <div class="row">
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">Date Form</label>
                      <input type="text" class="form-control"  placeholder="e.g 2014">
                    </div>
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">Date To</label>
                      <input type="text" class="form-control"  placeholder="e.g 2018">
                    </div>
                  </div>
                </div> 
                <div class="form-group">
                  <label class="control-label" for="textarea">Description</label>
                </div>  
                <section id="editor" style="margin-bottom: 30px;">
                  <div id="summernote"><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem quia aut modi fugit, ratione saepe perferendis odio optio repellat dolorum voluptas excepturi possimus similique veritatis nobis. Provident cupiditate delectus, optio?</p></div>
                </section>
                <div class="form-group">
                  <div class="button-group">
                    <div class="action-buttons">
                      <div class="upload-button">
                        <button class="btn btn-common">Choose a cover Logo</button>
                        <input id="cover_img_file" type="file">
                      </div>
                    </div>
                  </div>
                </div> 
                <div class="add-post-btn">
                  <div class="pull-left">
                    <a href="#" class="btn-added"><i class="ti-plus"></i> Add New Experience</a>
                  </div>
                  <div class="pull-right">
                    <a href="#" class="btn-delete"><i class="ti-trash"></i> Delete This</a>
                  </div>
                </div> 
                <div class="divider"><h3>Skills</h3></div>   
                <div class="form-group">
                  <div class="row">
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">Skill Name</label>
                      <input class="form-control" placeholder="Skill name, e.g. HTML" type="text">
                    </div>
                    <div class="col-md-6">
                      <label class="control-label" for="textarea">% (1-100)</label>
                      <input class="form-control" placeholder="Skill proficiency, e.g. 90" type="text">
                    </div>
                  </div>
                </div> 
                <div class="add-post-btn">
                  <div class="pull-left">
                    <a href="#" class="btn-added"><i class="ti-plus"></i> Add New Skills</a>
                  </div>
                  <div class="pull-right">
                    <a href="#" class="btn-delete"><i class="ti-trash"></i> Delete This</a>
                  </div>
                </div>                                    
              </form>
              <a href="resume.html" class="btn btn-common">Save</a>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Content section End -->     
      

@endsection

@push('scripts')
<script>
  $(function() {
    $('#summernote').summernote({
      height: 250,
      focus: true
    });
  });
</script>
@endpush
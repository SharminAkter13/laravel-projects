<?php $__env->startSection('page'); ?>
<div class="container mt-4 p-5">
    <h2>Jobs</h2>
    <a href="<?php echo e(route('jobs.create')); ?>" class="btn btn-primary mb-3">+ Add Job</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Category</th>
                <th>Company</th>
                <th>Location</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($job->id); ?></td>
                <td><?php echo e($job->title); ?></td>
                <td><?php echo e($job->category->name ?? 'N/A'); ?></td>
                <td><?php echo e($job->company_name); ?></td>
                <td><?php echo e($job->location); ?></td>
                <td><?php echo e($job->status); ?></td>
                <td>
                    <a href="<?php echo e(route('jobs.edit', $job->id)); ?>" class="btn btn-sm btn-warning">Edit</a>
                    <form action="<?php echo e(route('jobs.destroy', $job->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this job?')">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\jobs\index.blade.php ENDPATH**/ ?>
<?php echo $__env->make('portal_layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="main-content"> 

    <?php echo $__env->make('portal_layouts.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?> 

    <?php echo $__env->make('portal_layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\main.blade.php ENDPATH**/ ?>
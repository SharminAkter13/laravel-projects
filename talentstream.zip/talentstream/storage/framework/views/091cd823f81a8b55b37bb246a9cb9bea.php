<?php $__env->startSection('page'); ?>
<div class="card">
<div class="header pb-5 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 50px; background-image: url(../assets/img/theme/profile-cover.jpg); background-size: cover; background-position: center top;">
  <!-- Mask -->
  <span class="mask bg-gradient-default opacity-8"></span>
  <!-- Header container -->
  <div class="container-fluid d-flex align-items-center">
    <div class="row align-items-center">
    <div class="col-lg-12 col-md-10 text-center">
        <h1 class="display-2 text-white text-center"> Users List</h1>
        <a href="<?php echo e(route('userCreate')); ?>" class="btn btn-info">Add Users</a>
    </div>
</div>
    </div>
  </div>
</div>

<div>


<table class="table table-striped">

</table>
      <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Password</th>
     <th scope="col">Action</th>

    </tr>
  </thead>
    <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
      <th scope="row"><?php echo e($loop->iteration); ?></th>
      <td><?php echo e($u->name); ?></td>
      <td><?php echo e($u->email); ?></td>
      <td><?php echo e($u->password); ?></td>
      <td>
          <div class="btn-group">
                      <a href="<?php echo e(route('userEdit', $u->id)); ?>">
                        <button class="btn btn-md btn-success me-1 p-1"><i class="bi bi-pencil-square"></i></button>
                      </a>

                      <form action="<?php echo e(route('delete')); ?>" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="text" name="user_id" value="<?php echo e($u->id); ?>" hidden>
                      <button class="btn btn-md btn-danger  p-1"><i class="bi bi-trash3-fill"></i></button>
                </form>


                    </div>

      </td>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>



</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\interview\interviews.blade.php ENDPATH**/ ?>
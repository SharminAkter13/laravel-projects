<?php $__env->startSection('page'); ?>
<div class="card">
  <div class="header pb-5 pt-5 pt-lg-8 d-flex align-items-center" style="min-height: 50px; background-image: url(../assets/img/theme/profile-cover.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
      <div class="row align-items-center">
        <div class="col-lg-12 col-md-10 text-center">
            <h1 class="display-2 text-white text-center"> Resume List</h1>
            <a href="<?php echo e(route('resumes.create')); ?>" class="btn btn-info">Add Resume</a>
        </div>
      </div>
</div>
</div>

<div class="container mt-4">
  <div class="card shadow-sm">
    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
      <h4 class="mb-0">All Resumes</h4>
        <a href="<?php echo e(route('resumes.create')); ?>" class="btn btn-light btn-sm">+ Add Resume</a>    </div>

    <div class="card-body">
      <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>

      <table class="table table-bordered table-hover">
        <thead class="table-light">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Profession</th>
            <th>Location</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $resumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($resume->id); ?></td>
              <td><?php echo e($resume->name); ?></td>
              <td><?php echo e($resume->email); ?></td>
              <td><?php echo e($resume->profession_title); ?></td>
              <td><?php echo e($resume->location); ?></td>
              <td>
                <a href="<?php echo e(route('resumes.show', $resume->id)); ?>" class="btn btn-info btn-sm">View</a>
                <form action="<?php echo e(route('resumes.destroy', $resume->id)); ?>" method="POST" style="display:inline-block">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete this resume?')">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center">No resumes found.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\resumes\resume.blade.php ENDPATH**/ ?>
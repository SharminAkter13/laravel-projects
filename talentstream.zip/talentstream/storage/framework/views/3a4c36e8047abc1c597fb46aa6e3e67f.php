<?php $__env->startSection('page'); ?>
<div class="container mt-4">
    <div class="card">
        <div class="card-header">
            <h5>Edit Job Alert</h5>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('job_alerts.update', $jobAlert->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-3">
                    <label class="form-label">Alert Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($jobAlert->title); ?>" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Keywords</label>
                    <input type="text" name="keywords" class="form-control" value="<?php echo e($jobAlert->keywords); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Location</label>
                    <input type="text" name="location" class="form-control" value="<?php echo e($jobAlert->location); ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Contract Type</label>
                    <select name="contract_type" class="form-select">
                        <option value="full‑time" <?php echo e($jobAlert->contract_type == 'full‑time' ? 'selected' : ''); ?>>Full-Time</option>
                        <option value="part‑time" <?php echo e($jobAlert->contract_type == 'part‑time' ? 'selected' : ''); ?>>Part-Time</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Frequency</label>
                    <select name="frequency" class="form-select">
                        <option value="daily" <?php echo e($jobAlert->frequency == 'daily' ? 'selected' : ''); ?>>Daily</option>
                        <option value="weekly" <?php echo e($jobAlert->frequency == 'weekly' ? 'selected' : ''); ?>>Weekly</option>
                        <option value="monthly" <?php echo e($jobAlert->frequency == 'monthly' ? 'selected' : ''); ?>>Monthly</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-success">Update Alert</button>
                <a href="<?php echo e(route('job_alerts.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\job-alerts\edit.blade.php ENDPATH**/ ?>
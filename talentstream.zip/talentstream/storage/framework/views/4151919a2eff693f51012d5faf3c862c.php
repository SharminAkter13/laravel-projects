<?php $__env->startSection('page'); ?>
<div class="container mt-4 p-5">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="mb-0">Create Category</h2>
            <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary btn-sm">Back to Categories</a>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('categories.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label>Icon (optional)</label>
                    <input type="text" name="icon" class="form-control">
                </div>
                <button class="btn btn-success">Create</button>
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\categories\create.blade.php ENDPATH**/ ?>
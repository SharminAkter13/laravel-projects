<?php $__env->startSection('page'); ?>
<div class="container mt-4 p-5">
  <div class="card shadow-sm">
    <div class="card-header bg-info text-white">
      <h4><?php echo e($resume->name); ?>’s Resume</h4>
    </div>

    <div class="card-body">
      <p><strong>Email:</strong> <?php echo e($resume->email); ?></p>
      <p><strong>Profession:</strong> <?php echo e($resume->profession_title); ?></p>
      <p><strong>Location:</strong> <?php echo e($resume->location); ?></p>
      <p><strong>Website:</strong> <?php echo e($resume->web); ?></p>
      <p><strong>Hourly Rate:</strong> <?php echo e($resume->pre_hour); ?></p>
      <p><strong>Age:</strong> <?php echo e($resume->age); ?></p>

      <hr>
      <h5 class="text-primary">🎓 Education</h5>
      <ul>
        <?php $__currentLoopData = $resume->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><strong><?php echo e($edu->degree); ?></strong> — <?php echo e($edu->school); ?> (<?php echo e($edu->edu_from); ?> - <?php echo e($edu->edu_to); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <h5 class="text-primary">💼 Experience</h5>
      <ul>
        <?php $__currentLoopData = $resume->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><strong><?php echo e($exp->title); ?></strong> at <?php echo e($exp->company_name); ?> (<?php echo e($exp->exp_from); ?> - <?php echo e($exp->exp_to); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <h5 class="text-primary">🧠 Skills</h5>
      <ul>
        <?php $__currentLoopData = $resume->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($skill->skill_name); ?> — <?php echo e($skill->skill_percent); ?>%</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\talentstream\resources\views\pages\resumes\show-resume.blade.php ENDPATH**/ ?>